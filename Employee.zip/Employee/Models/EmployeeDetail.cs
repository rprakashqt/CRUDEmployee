namespace Employee.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("EmployeeDetail")]
    public partial class EmployeeDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long EmployeeId { get; set; }

        [Required(ErrorMessage = "Enter first name")]
        [Display(Name = "First Name", Prompt = "Enter first name", Description = "Employee first name")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Enter last name")]
        [Display(Name = "Last Name", Prompt = "Enter last name", Description = "Employee last name")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Select role")]
        [StringLength(25)]
        [UIHint("YesNoDropDown")]
        public string Role { get; set; }

        [Required(ErrorMessage = "Enter address detail")]
        [Display(Name = "Address", Prompt = "Enter address detail", Description = "Employee address detail")]
        [DataType(DataType.MultilineText)]
        [StringLength(250, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 250 charactor")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Enter city")]
        [Display(Name = "City", Prompt = "Enter city", Description = "Employee city")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string City { get; set; }

        [Required(ErrorMessage ="Enter state")]
        [Display(Name = "State", Prompt = "Enter state", Description = "Employee state")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string State { get; set; }

        [Required(ErrorMessage = "Enter country")]
        [Display(Name = "Country", Prompt = "Enter country", Description = "Employee country")]
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Enter zipcode")]
        [StringLength(10, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        public string Zipcode { get; set; }

        [Required(ErrorMessage = "Enter username")]
        [Display(Name = "Username", Prompt = "Enter login username", Description = "Employee login username")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        
        public string UserName { get; set; }

        [Required(ErrorMessage = "Enter password")]
        [RegularExpression(@"^[a-zA-Z][a-zA-Z0-9]*$", ErrorMessage = "Password must be alphanumeric")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        [DataType(DataType.Password)]
        
        public string Password { get; set; }

        [Required(ErrorMessage = "Re-enter password")]
        [Display(Name = "Re-enter password")]
        [RegularExpression(@"^[a-zA-Z][a-zA-Z0-9]*$", ErrorMessage = "Password must be alphanumeric")]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Required minimum 1 to 50 charactor")]
        [NotMapped]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

        public DateTime CreatedDate { get; set; }

        public bool IsDeleted { get; set; }
    }
}
