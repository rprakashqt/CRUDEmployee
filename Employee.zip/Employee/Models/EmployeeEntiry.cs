namespace Employee.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class EmployeeEntiry : DbContext
    {
        public EmployeeEntiry()
            : base("name=EmployeeEntiry")
        {
        }

        public virtual DbSet<EmployeeDetail> EmployeeDetail { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeDetail>()
                .Property(e => e.Country)
                .IsFixedLength();
        }
    }
}
