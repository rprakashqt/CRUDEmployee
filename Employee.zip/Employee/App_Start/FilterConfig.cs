﻿using System.Web;
using System;
using System.Web.Mvc;
using System.Web.Mvc.Filters;
namespace Employee
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }

    public class ControllerHandler : FilterAttribute, IExceptionFilter
    {      
       

        public void OnException(ExceptionContext filterContext)
        {
            if (!filterContext.ExceptionHandled)
            {
                filterContext.Result = new RedirectResult("~/Content/RangeErrorPage.html");
                filterContext.ExceptionHandled = true;
            }
        }
    }

    public class AuthorizationHandler : IAuthorizationFilter
    {

        public void OnAuthorization(AuthorizationContext filterContext)
        {
            
            if(!filterContext.RequestContext.HttpContext.Request.IsAuthenticated)
            {
                filterContext.Result = new RedirectResult("~/Home/Login", true);
            }
        }
    }

}
