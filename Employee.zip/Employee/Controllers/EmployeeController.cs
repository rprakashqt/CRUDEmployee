﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Employee.Models;

namespace Employee.Controllers
{
    [ControllerHandler]
    public class EmployeeController : Controller
    {
        private EmployeeEntiry db = new EmployeeEntiry();

        // GET: Employee
        public async Task<ActionResult> Index()
        {
            return View(await db.EmployeeDetail.Where(xx => !xx.IsDeleted).ToListAsync());
        }

        // GET: Employee/Details/5
        public async Task<ActionResult> Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = await db.EmployeeDetail.FindAsync(id);
            if (employeeDetail == null)
            {
                return HttpNotFound();
            }
            return View(employeeDetail);
        }

        // GET: Employee/Create

        public ActionResult Create()
        {
            return View();
        }

        // POST: Employee/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "FirstName,LastName,Role,Address,City,State,Country,Zipcode,UserName,Password,ConfirmPassword", Exclude = "CreatedDate,IsDeleted,EmployeeId")] EmployeeDetail employeeDetail)
        {
            if (ModelState.IsValid)
            {
                if (!IsUserNameExists(employeeDetail.UserName, employeeDetail.EmployeeId))
                {
                    employeeDetail.CreatedDate = DateTime.Now;
                    employeeDetail.IsDeleted = false;
                    db.EmployeeDetail.Add(employeeDetail);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("UserName", "Username alreay exists");
                }
            }

            return View(employeeDetail);
        }

        // GET: Employee/Edit/5
        public async Task<ActionResult> Edit(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = await db.EmployeeDetail.FindAsync(id);
            if (employeeDetail == null)
            {
                return HttpNotFound();
            }
            return View(employeeDetail);
        }

        // POST: Employee/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "EmployeeId,FirstName,LastName,Role,Address,City,State,Country,Zipcode,UserName,Password,Password,ConfirmPassword,CreatedDate,IsDeleted")] EmployeeDetail employeeDetail)
        {
            if (ModelState.IsValid)
            {
                
                if(!IsUserNameExists(employeeDetail.UserName, employeeDetail.EmployeeId))
                {
                    db.Entry(employeeDetail).State = EntityState.Modified;
                    await db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("UserName", "Username alreay exists");
                }
              
            }
            return View(employeeDetail);
        }

        // GET: Employee/Delete/5       
        public async Task<ActionResult> Delete(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeDetail employeeDetail = await db.EmployeeDetail.FindAsync(id);
            if (employeeDetail == null)
            {
                return HttpNotFound();
            }
            return View(employeeDetail);
        }

        // POST: Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]        
        public async Task<ActionResult> DeleteConfirmed(long id)
        {
            EmployeeDetail employeeDetail = await db.EmployeeDetail.FindAsync(id);
            db.EmployeeDetail.Remove(employeeDetail);
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        public bool IsUserNameExists(string userName, long empId)
        {
            return db.EmployeeDetail.Any(xx => xx.UserName == userName && xx.EmployeeId != empId) ? true : false;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
