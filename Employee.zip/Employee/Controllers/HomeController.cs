﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using System.Web.Security;
using Employee.Models;
using System.Security.Principal;
using System.Threading;

namespace Employee.Controllers
{

    public class HomeController : Controller
    {
        private EmployeeEntiry dbEntity = new EmployeeEntiry();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Login()
        {
            ViewData["errormessage"] = "";
            return View("Login");
        }
        [HttpPost]
        public async Task<ActionResult> Login(FormCollection form)
        {

            string userName = Request.Form["login"];
            string password = Request.Form["password"];
            string message = "";
            if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(userName))
            {
                message = "Invalid user and password";
            }
            else
            {
                var empDetail = dbEntity.EmployeeDetail.Where(xx => xx.UserName == userName && xx.Password == password && !xx.IsDeleted).FirstOrDefault();
                if (empDetail != null)
                {
                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, empDetail.UserName, DateTime.Now,
                        DateTime.Now.AddMinutes(2880), true, empDetail.Role, FormsAuthentication.FormsCookiePath);
                    string hash = FormsAuthentication.Encrypt(ticket);
                    HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, hash);                
                   

                    if (ticket.IsPersistent)
                    {

                        cookie.Expires = ticket.Expiration;
                    }
                    Response.Cookies.Add(cookie);
                }
                else
                {
                    message = "Invalid user and password";
                }
            }
            if (string.IsNullOrEmpty(message))
            {
                return RedirectToAction("Index", "Employee");
            }
            else
            {
                ViewData["errormessage"] = message;
                return View("Login");
            }

        }
    }
}